"""router.py — Top-k gating router for sparse MoE.

Inspired by Colibri sparse.md:
- Each layer has N experts, router selects top-k
- Only k/N experts are activated per token
- Load balancing loss prevents expert collapse
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class TopKRouter(nn.Module):
    """Top-k router with load balancing auxiliary loss."""

    def __init__(
        self,
        hidden_size: int,
        num_experts: int,
        top_k: int = 8,
        noise_std: float = 0.0,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_experts = num_experts
        self.top_k = top_k
        self.noise_std = noise_std

        # Router linear layer
        self.gate = nn.Linear(hidden_size, num_experts, bias=False)

        # Load balancing coefficient
        self.lb_coef = 0.01

    def forward(self, hidden: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Args:
            hidden: [batch, seq_len, hidden_size]

        Returns:
            expert_weights: [batch, seq_len, top_k] — softmax weights for selected experts
            expert_indices: [batch, seq_len, top_k] — indices of selected experts
            aux_loss: scalar — load balancing auxiliary loss
        """
        batch, seq_len, _ = hidden.shape

        # Compute routing logits
        router_logits = self.gate(hidden)  # [batch, seq_len, num_experts]

        # Add noise for exploration (training only)
        if self.training and self.noise_std > 0:
            noise = torch.randn_like(router_logits) * self.noise_std
            router_logits = router_logits + noise

        # Top-k selection
        weights, indices = torch.topk(
            F.softmax(router_logits, dim=-1),
            k=self.top_k,
            dim=-1,
        )  # weights: [B, S, K], indices: [B, S, K]

        # Renormalize weights over selected experts
        weights = weights / (weights.sum(dim=-1, keepdim=True) + 1e-9)

        # Load balancing auxiliary loss
        # Encourage uniform expert utilization
        aux_loss = self._compute_load_balance_loss(router_logits, indices)

        return weights, indices, aux_loss

    def _compute_load_balance_loss(
        self,
        router_logits: torch.Tensor,
        expert_indices: torch.Tensor,
    ) -> torch.Tensor:
        """Compute load balancing loss to prevent expert collapse.

        Reference: Switch Transformer (Fedus et al., 2022)
        loss = N * sum(f_i * P_i) where
        - f_i = fraction of tokens routed to expert i
        - P_i = average routing probability to expert i
        """
        num_tokens = router_logits.size(0) * router_logits.size(1)
        num_experts = self.num_experts

        # f_i: fraction of tokens routed to each expert
        expert_mask = F.one_hot(
            expert_indices, num_classes=num_experts
        ).sum(dim=-2)  # [B, S, N] → sum over top_k dim
        f = expert_mask.float().sum(dim=(0, 1)) / num_tokens  # [N]

        # P_i: average routing probability
        P = F.softmax(router_logits, dim=-1).mean(dim=(0, 1))  # [N]

        # Load balance loss
        aux_loss = num_experts * (f * P).sum()

        return self.lb_coef * aux_loss


class ExpertChoiceRouter(nn.Module):
    """Alternative: Expert Choice routing (ECR).

    Each expert chooses top-k tokens instead of each token choosing top-k experts.
    Better load balancing, used in GLaM and ST-MoE.
    """

    def __init__(self, hidden_size: int, num_experts: int, capacity_factor: float = 1.25):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_experts = num_experts
        self.capacity_factor = capacity_factor
        self.gate = nn.Linear(hidden_size, num_experts, bias=False)

    def forward(self, hidden: torch.Tensor):
        """Expert Choice routing.

        Returns:
            token_assignments: [batch, seq_len] — which expert handles each token
            expert_weights: [batch, seq_len] — weight for the assignment
        """
        batch, seq_len, _ = hidden.shape
        router_logits = self.gate(hidden)  # [B, S, N]

        # Each expert picks top-k tokens
        capacity = int(self.capacity_factor * seq_len / self.num_experts)

        # Transpose: [B, N, S]
        expert_preferences = router_logits.transpose(1, 2)  # [B, N, S]

        # Top-k tokens per expert
        _, top_token_indices = torch.topk(expert_preferences, k=capacity, dim=-1)

        # Build assignment matrix
        # This is more complex — simplified here
        # Full implementation needs scatter/gather

        # For now, fall back to token-choice with capacity limit
        weights, indices = torch.topk(
            F.softmax(router_logits, dim=-1), k=1, dim=-1
        )
        return weights.squeeze(-1), indices.squeeze(-1)
