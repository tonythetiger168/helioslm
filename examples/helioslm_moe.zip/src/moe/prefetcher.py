"""prefetcher.py — Lookahead expert prefetcher.

Inspired by Colibri token-path.png:
- Predict which experts will be needed at layer L+1
- Prefetch them to RAM (warm tier) before they are needed
- 71.6% predictability in Colibri

Usage:
    prefetcher = ExpertPrefetcher(hidden_size=768, num_experts=256)
    next_experts = prefetcher.predict(current_hidden, top_k=16)
    cache.prefetch(layer_idx + 1, next_experts)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List


class ExpertPrefetcher(nn.Module):
    """Lightweight predictor for next-layer expert usage."""

    def __init__(
        self,
        hidden_size: int,
        num_experts: int,
        predictor_hidden: int = 256,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_experts = num_experts

        # Small MLP predictor
        self.predictor = nn.Sequential(
            nn.Linear(hidden_size, predictor_hidden),
            nn.ReLU(),
            nn.Linear(predictor_hidden, num_experts),
        )

        # Training: learn from actual router decisions
        self._trained = False

    def forward(self, hidden: torch.Tensor) -> torch.Tensor:
        """Predict expert probability distribution for next layer."""
        return self.predictor(hidden)  # [batch, seq, num_experts]

    def predict(
        self,
        hidden: torch.Tensor,
        top_k: int = 16,
        threshold: float = 0.1,
    ) -> List[int]:
        """
        Predict which experts to prefetch.

        Args:
            hidden: [batch, seq, hidden_size] — current layer output
            top_k: number of experts to prefetch per token
            threshold: minimum probability to consider

        Returns:
            List of expert indices to prefetch
        """
        with torch.no_grad():
            logits = self.predictor(hidden)  # [B, S, N]
            probs = F.softmax(logits, dim=-1)  # [B, S, N]

            # Aggregate across batch and sequence
            # Simple: max pooling across tokens
            token_max = probs.max(dim=1)[0]  # [B, N]
            batch_mean = token_max.mean(dim=0)  # [N]

            # Select experts above threshold
            mask = batch_mean > threshold
            candidates = torch.where(mask)[0].tolist()

            # If too few, add top-k by probability
            if len(candidates) < top_k:
                _, top_indices = torch.topk(batch_mean, k=top_k)
                candidates = list(set(candidates + top_indices.tolist()))

            return candidates[:top_k * 2]  # Prefetch 2x for safety

    def train_step(
        self,
        hidden: torch.Tensor,
        actual_experts: torch.Tensor,
        optimizer: torch.optim.Optimizer,
    ) -> float:
        """Train predictor on actual router decisions.

        Args:
            hidden: [batch, seq, hidden_size] — input to predictor
            actual_experts: [batch, seq, top_k] — experts chosen by router
            optimizer: optimizer for predictor

        Returns:
            loss value
        """
        logits = self.predictor(hidden)  # [B, S, N]

        # Target: multi-label binary classification
        # Each expert is either selected (1) or not (0)
        batch, seq, _ = logits.shape
        target = torch.zeros(batch, seq, self.num_experts, device=hidden.device)
        for b in range(batch):
            for s in range(seq):
                for k in range(actual_experts.size(-1)):
                    idx = actual_experts[b, s, k].item()
                    target[b, s, idx] = 1.0

        # Binary cross entropy per expert
        loss = F.binary_cross_entropy_with_logits(
            logits, target, reduction="mean"
        )

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        self._trained = True
        return loss.item()


class AsyncPrefetcher:
    """Async wrapper for non-blocking prefetch."""

    def __init__(self, cache, prefetcher, num_workers: int = 2):
        self.cache = cache
        self.prefetcher = prefetcher
        self.num_workers = num_workers
        self._prefetch_queue = []

    def schedule(self, layer_idx: int, hidden: torch.Tensor):
        """Schedule prefetch for next layer."""
        next_layer = layer_idx + 1
        expert_indices = self.prefetcher.predict(hidden)
        self._prefetch_queue.append((next_layer, expert_indices))

    def execute(self):
        """Execute pending prefetches."""
        for layer_idx, indices in self._prefetch_queue:
            # Only load to RAM (warm), not VRAM
            # VRAM loading happens in forward() when actually needed
            for idx in indices:
                if (layer_idx, idx) not in self.cache._ram:
                    # Trigger disk → RAM load
                    pass  # Actual implementation needs async IO
        self._prefetch_queue.clear()
