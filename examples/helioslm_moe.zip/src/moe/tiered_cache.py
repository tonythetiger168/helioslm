"""tiered_cache.py — VRAM → RAM → Disk three-tier expert cache.

Inspired by Colibri (chientung/colibri, Apache-2.0):
- Hot: VRAM (GPU),常驻
- Warm: RAM (host memory), pinned
- Cold: Disk (NVMe), load on demand

Usage:
    cache = TieredExpertCache(vram_limit_gb=8, ram_limit_gb=32)
    cache.route(layer_idx=0, expert_indices=[3, 7, 15])
    expert = cache.get(layer_idx=0, expert_idx=7)
"""

import os
import time
import torch
import torch.nn as nn
from collections import OrderedDict
from typing import Dict, List, Optional, Tuple
import threading


class TieredExpertCache:
    """Three-tier expert cache: VRAM (hot) → RAM (warm) → Disk (cold)."""

    def __init__(
        self,
        vram_limit_gb: float = 8.0,
        ram_limit_gb: float = 32.0,
        disk_path: str = "./expert_cache",
        dtype: torch.dtype = torch.bfloat16,
    ):
        self.vram_limit = int(vram_limit_gb * 1024 ** 3)
        self.ram_limit = int(ram_limit_gb * 1024 ** 3)
        self.disk_path = disk_path
        self.dtype = dtype

        os.makedirs(disk_path, exist_ok=True)

        # Hot tier: GPU VRAM
        self._vram: Dict[Tuple[int, int], nn.Module] = OrderedDict()
        self._vram_bytes = 0

        # Warm tier: Host RAM (pinned CPU tensors)
        self._ram: Dict[Tuple[int, int], Dict[str, torch.Tensor]] = OrderedDict()
        self._ram_bytes = 0

        # Cold tier: Disk (state_dict files)
        # Key format: (layer_idx, expert_idx) → file path
        self._disk_index: set = set()
        self._build_disk_index()

        # Lock for thread-safe access
        self._lock = threading.RLock()

        # Stats
        self.stats = {
            "vram_hits": 0,
            "ram_hits": 0,
            "disk_loads": 0,
            "evictions_to_ram": 0,
            "evictions_to_disk": 0,
        }

    def _build_disk_index(self):
        """Scan disk_path for existing expert checkpoints."""
        if not os.path.exists(self.disk_path):
            return
        for fname in os.listdir(self.disk_path):
            if fname.endswith(".pt"):
                # Format: expert_L{layer}_E{expert}.pt
                try:
                    parts = fname.replace(".pt", "").split("_")
                    layer = int(parts[1][1:])  # L{layer}
                    expert = int(parts[2][1:])  # E{expert}
                    self._disk_index.add((layer, expert))
                except (IndexError, ValueError):
                    continue

    def register_expert(self, layer_idx: int, expert_idx: int, expert: nn.Module):
        """Register an expert to the cache (typically at model init)."""
        key = (layer_idx, expert_idx)
        with self._lock:
            # Save to disk as cold tier master copy
            fpath = os.path.join(self.disk_path, f"expert_L{layer_idx}_E{expert_idx}.pt")
            torch.save(expert.state_dict(), fpath)
            self._disk_index.add(key)

    def route(self, layer_idx: int, expert_indices: List[int]):
        """Ensure requested experts are loaded (promote from cold/warm to hot)."""
        for idx in expert_indices:
            self._ensure_loaded(layer_idx, idx)

    def get(self, layer_idx: int, expert_idx: int) -> nn.Module:
        """Get expert from cache (must call route() first)."""
        key = (layer_idx, expert_idx)
        with self._lock:
            if key in self._vram:
                self.stats["vram_hits"] += 1
                # Move to end (MRU)
                self._vram.move_to_end(key)
                return self._vram[key]

            # Fallback: load on demand (should not happen if route() called)
            self._ensure_loaded(layer_idx, expert_idx)
            return self._vram[key]

    def _ensure_loaded(self, layer_idx: int, expert_idx: int):
        """Load expert into VRAM, promoting from RAM or Disk as needed."""
        key = (layer_idx, expert_idx)

        # Already in VRAM
        if key in self._vram:
            return

        # In RAM → promote to VRAM
        if key in self._ram:
            self.stats["ram_hits"] += 1
            state = self._ram.pop(key)
            self._ram_bytes -= self._estimate_state_bytes(state)
            expert = self._reconstruct_expert(state)
            self._place_in_vram(key, expert)
            return

        # On Disk → load to RAM → promote to VRAM
        if key in self._disk_index:
            self.stats["disk_loads"] += 1
            fpath = os.path.join(self.disk_path, f"expert_L{layer_idx}_E{expert_idx}.pt")
            state = torch.load(fpath, map_location="cpu")
            # Store in RAM first
            self._place_in_ram(key, state)
            # Then promote to VRAM
            expert = self._reconstruct_expert(state)
            self._place_in_vram(key, expert)
            return

        raise KeyError(f"Expert {key} not found in any tier")

    def _place_in_vram(self, key: Tuple[int, int], expert: nn.Module):
        """Place expert in VRAM, evicting LRU if necessary."""
        expert_bytes = self._estimate_module_bytes(expert)

        with self._lock:
            # Evict LRU until we have space
            while self._vram_bytes + expert_bytes > self.vram_limit and self._vram:
                self._evict_lru_from_vram()

            self._vram[key] = expert.to("cuda")
            self._vram_bytes += expert_bytes
            self._vram.move_to_end(key)

    def _place_in_ram(self, key: Tuple[int, int], state: Dict[str, torch.Tensor]):
        """Place state dict in RAM, evicting LRU if necessary."""
        state_bytes = self._estimate_state_bytes(state)

        with self._lock:
            while self._ram_bytes + state_bytes > self.ram_limit and self._ram:
                self._evict_lru_from_ram()

            self._ram[key] = state
            self._ram_bytes += state_bytes
            self._ram.move_to_end(key)

    def _evict_lru_from_vram(self):
        """Evict least-recently-used expert from VRAM to RAM."""
        if not self._vram:
            return
        key, expert = self._vram.popitem(last=False)
        self._vram_bytes -= self._estimate_module_bytes(expert)

        # Convert to state dict and store in RAM
        state = {k: v.cpu() for k, v in expert.state_dict().items()}
        self._place_in_ram(key, state)
        self.stats["evictions_to_ram"] += 1

    def _evict_lru_from_ram(self):
        """Evict least-recently-used state from RAM (discard, disk has master)."""
        if not self._ram:
            return
        key, state = self._ram.popitem(last=False)
        self._ram_bytes -= self._estimate_state_bytes(state)
        self.stats["evictions_to_disk"] += 1
        # No need to write back — disk already has master copy

    def _reconstruct_expert(self, state: Dict[str, torch.Tensor]) -> nn.Module:
        """Reconstruct expert module from state dict.

        NOTE: This is a placeholder. Actual implementation needs expert
        architecture info. For now, assume caller provides factory.
        """
        # In practice, the SparseMoELayer will hold expert factories
        raise NotImplementedError("Use SparseMoELayer.get_expert() instead")

    def _estimate_module_bytes(self, module: nn.Module) -> int:
        """Estimate GPU memory usage of a module."""
        total = 0
        for p in module.parameters():
            total += p.numel() * p.element_size()
        for b in module.buffers():
            total += b.numel() * b.element_size()
        return total

    def _estimate_state_bytes(self, state: Dict[str, torch.Tensor]) -> int:
        """Estimate bytes of a state dict."""
        return sum(v.numel() * v.element_size() for v in state.values())

    def report(self) -> Dict:
        """Return cache statistics."""
        total_hits = self.stats["vram_hits"] + self.stats["ram_hits"]
        total_accesses = total_hits + self.stats["disk_loads"]
        hit_rate = total_hits / total_accesses if total_accesses > 0 else 0

        return {
            "vram_occupied_gb": self._vram_bytes / (1024 ** 3),
            "vram_limit_gb": self.vram_limit / (1024 ** 3),
            "ram_occupied_gb": self._ram_bytes / (1024 ** 3),
            "ram_limit_gb": self.ram_limit / (1024 ** 3),
            "vram_entries": len(self._vram),
            "ram_entries": len(self._ram),
            "disk_entries": len(self._disk_index),
            "hit_rate": hit_rate,
            **self.stats,
        }
