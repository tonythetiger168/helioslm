"""sparse_moe.py — Sparse MoE layer with tiered expert cache.

Core design:
- Each layer has N experts (e.g., 256)
- Router selects top-k (e.g., 8) per token
- Only k experts are activated → 3.1% compute
- Experts live in TieredExpertCache (VRAM/RAM/Disk)

Usage:
    moe_layer = SparseMoELayer(hidden_size=768, num_experts=256, top_k=8)
    output = moe_layer(hidden)  # [batch, seq, hidden]
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional

from .router import TopKRouter
from .tiered_cache import TieredExpertCache


class ExpertFFN(nn.Module):
    """Single expert: standard SwiGLU FFN."""

    def __init__(self, hidden_size: int, intermediate_size: int, dropout: float = 0.0):
        super().__init__()
        self.hidden_size = hidden_size
        self.intermediate_size = intermediate_size

        # SwiGLU: split into gate and up
        self.gate_proj = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.up_proj = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.down_proj = nn.Linear(intermediate_size, hidden_size, bias=False)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # SwiGLU: silu(gate) * up
        gate = F.silu(self.gate_proj(x))
        up = self.up_proj(x)
        hidden = gate * up
        hidden = self.dropout(hidden)
        return self.down_proj(hidden)


class SparseMoELayer(nn.Module):
    """Sparse MoE layer with top-k routing and tiered expert cache."""

    def __init__(
        self,
        hidden_size: int,
        num_experts: int = 256,
        top_k: int = 8,
        intermediate_size: Optional[int] = None,
        dropout: float = 0.0,
        layer_idx: int = 0,
        use_tiered_cache: bool = True,
        vram_limit_gb: float = 8.0,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_experts = num_experts
        self.top_k = top_k
        self.layer_idx = layer_idx
        self.use_tiered_cache = use_tiered_cache

        if intermediate_size is None:
            intermediate_size = int(hidden_size * 4 * 2 / 3)  # SwiGLU scaling
        self.intermediate_size = intermediate_size

        # Router (always in VRAM — small)
        self.router = TopKRouter(hidden_size, num_experts, top_k=top_k)

        # Expert factory for reconstruction
        self._expert_factory = lambda: ExpertFFN(
            hidden_size, intermediate_size, dropout
        )

        # Experts: either all in VRAM (small models) or tiered cache (large models)
        if use_tiered_cache:
            self.cache = TieredExpertCache(
                vram_limit_gb=vram_limit_gb,
                ram_limit_gb=32.0,
                disk_path=f"./expert_cache/layer_{layer_idx}",
            )
            # Register all experts to disk (cold tier)
            for i in range(num_experts):
                expert = self._expert_factory()
                self.cache.register_expert(layer_idx, i, expert)
            self.experts = None  # Not used in tiered mode
        else:
            # All experts in VRAM (for small models or debugging)
            self.experts = nn.ModuleList([
                self._expert_factory() for _ in range(num_experts)
            ])
            self.cache = None

    def forward(self, hidden: torch.Tensor) -> torch.Tensor:
        """
        Args:
            hidden: [batch, seq_len, hidden_size]

        Returns:
            output: [batch, seq_len, hidden_size]
        """
        batch, seq_len, hidden_size = hidden.shape

        # 1. Route: select top-k experts per token
        expert_weights, expert_indices, aux_loss = self.router(hidden)
        # expert_weights: [B, S, K]
        # expert_indices: [B, S, K]

        # 2. Load experts into cache (if tiered)
        if self.use_tiered_cache:
            unique_experts = torch.unique(expert_indices).tolist()
            self.cache.route(self.layer_idx, unique_experts)

        # 3. Compute: weighted sum of expert outputs
        output = torch.zeros_like(hidden)

        for k in range(self.top_k):
            # For each expert slot k
            idx_k = expert_indices[:, :, k]  # [B, S]
            weight_k = expert_weights[:, :, k:k+1]  # [B, S, 1]

            # Process each unique expert in this slot
            for b in range(batch):
                for s in range(seq_len):
                    expert_idx = idx_k[b, s].item()
                    w = weight_k[b, s]  # [1]

                    # Get expert
                    if self.use_tiered_cache:
                        expert = self.cache.get(self.layer_idx, expert_idx)
                    else:
                        expert = self.experts[expert_idx]

                    # Compute and accumulate
                    expert_out = expert(hidden[b:b+1, s:s+1])  # [1, 1, H]
                    output[b, s] += (w * expert_out).squeeze()

        # 4. Add auxiliary loss (stored for backward)
        output = output + 0.0  # Ensure gradient flow
        if self.training:
            # Attach aux_loss to output for retrieval
            output._moe_aux_loss = aux_loss

        return output

    def get_aux_loss(self) -> torch.Tensor:
        """Retrieve load balancing auxiliary loss from last forward."""
        # This should be called by the model after each MoE layer
        return torch.tensor(0.0)  # Placeholder — actual implementation needs hook

    def get_expert(self, idx: int) -> nn.Module:
        """Get expert by index (for cache reconstruction)."""
        if self.use_tiered_cache:
            return self.cache.get(self.layer_idx, idx)
        return self.experts[idx]

    @property
    def active_params(self) -> int:
        """Number of parameters activated per token."""
        expert = self._expert_factory()
        expert_params = sum(p.numel() for p in expert.parameters())
        return expert_params * self.top_k + sum(p.numel() for p in self.router.parameters())

    @property
    def total_params(self) -> int:
        """Total number of parameters (all experts)."""
        expert = self._expert_factory()
        expert_params = sum(p.numel() for p in expert.parameters())
        return expert_params * self.num_experts + sum(p.numel() for p in self.router.parameters())
